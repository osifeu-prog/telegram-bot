﻿import asyncio

from src.bot.db.database import engine
from src.bot.models.user import Base

async def main():
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

if __name__ == "__main__":
    asyncio.run(main())




