﻿from aiogram import Router, types
from aiogram.filters import Command
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from sqlalchemy import select
from src.bot.db.database import AsyncSessionLocal
from src.bot.db.models import User
from src.utils.i18n import get_string

router = Router()
ADMIN_ID = 8789977826

def get_user_lang(telegram_id: int) -> str:
    # This would normally query DB, but for now return default
    return "en"

def is_admin(msg: types.Message) -> bool:
    return msg.from_user.id == ADMIN_ID

def main_menu_keyboard(lang: str):
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🏠 Home", callback_data="menu_main")],
        [InlineKeyboardButton(text="🛒 Shop", callback_data="menu_shop"),
         InlineKeyboardButton(text="📊 Top", callback_data="menu_top")],
        [InlineKeyboardButton(text="👤 Profile", callback_data="menu_profile"),
         InlineKeyboardButton(text="❓ Help", callback_data="menu_help")],
    ])

def admin_menu_keyboard(lang: str):
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📋 Status", callback_data="admin_status"),
         InlineKeyboardButton(text="🔍 Check", callback_data="check_files")],
        [InlineKeyboardButton(text="⚙️ DevOps", callback_data="menu_devops"),
         InlineKeyboardButton(text="💰 Economy", callback_data="menu_economy")],
        [InlineKeyboardButton(text="🏛️ Governance", callback_data="menu_governance")],
        [InlineKeyboardButton(text="📊 Progress", callback_data="progress"),
         InlineKeyboardButton(text="❌ Missing", callback_data="missing")],
    ])

@router.message(Command("menu"))
async def menu_cmd(message: types.Message):
    lang = get_user_lang(message.from_user.id)
    if is_admin(message):
        await message.reply("🛠️ Admin Control Center", reply_markup=admin_menu_keyboard(lang))
    else:
        await message.reply("🏠 Main Menu", reply_markup=main_menu_keyboard(lang))

@router.message(Command("progress"))
async def progress_cmd(message: types.Message):
    if not is_admin(message):
        await message.reply(get_string("access_denied", get_user_lang(message.from_user.id)))
        return
    # Read system_status.json
    import json
    try:
        with open("ops/system_status.json", "r") as f:
            status = json.load(f)
    except FileNotFoundError:
        status = {"progress": {"mvp": 0.12, "v1": 0.03, "v2": 0.0}}
    
    mvp = status.get("progress", {}).get("mvp", 0) * 100
    v1 = status.get("progress", {}).get("v1", 0) * 100
    v2 = status.get("progress", {}).get("v2", 0) * 100
    
    await message.reply(
        f"📊 Progress\n\n"
        f"MVP: {mvp:.0f}% {'🟢'*int(mvp//10)}{'⚪'*(10-int(mvp//10))}\n"
        f"V1:  {v1:.0f}% {'🟢'*int(v1//10)}{'⚪'*(10-int(v1//10))}\n"
        f"V2:  {v2:.0f}% {'🟢'*int(v2//10)}{'⚪'*(10-int(v2//10))}"
    )

@router.message(Command("missing"))
async def missing_cmd(message: types.Message):
    if not is_admin(message):
        await message.reply(get_string("access_denied", get_user_lang(message.from_user.id)))
        return
    import json, os
    try:
        with open("ops/system_status.json", "r") as f:
            status = json.load(f)
    except FileNotFoundError:
        status = {}
    
    missing_files = [f for f, exists in status.get("files", {}).items() if not exists]
    missing_features = [f for f, exists in status.get("features", {}).items() if not exists]
    
    msg = "❌ Missing Items\n\n"
    if missing_files:
        msg += "📁 Files:\n" + "\n".join(f"  • {f}" for f in missing_files) + "\n"
    if missing_features:
        msg += "🎯 Features:\n" + "\n".join(f"  • {f}" for f in missing_features) + "\n"
    if not missing_files and not missing_features:
        msg += "✅ Nothing missing!"
    
    await message.reply(msg)

@router.message(Command("roadmap"))
async def roadmap_cmd(message: types.Message):
    await message.reply(
        "🗺️ Roadmap\n\n"
        "🥇 MVP: Daily loop + Boost payment\n"
        "🥈 V1: Community + Voting + Shop\n"
        "🥉 V2: Secrets + Premium + Full Dashboard\n"
        "🔮 V3: Referral + KYC + Analytics"
    )

@router.message(Command("checklist"))
async def checklist_cmd(message: types.Message):
    if not is_admin(message):
        await message.reply(get_string("access_denied", get_user_lang(message.from_user.id)))
        return
    await message.reply(
        "✔️ Checklist\n\n"
        "• Webhook: ✅\n"
        "• DB: ✅\n"
        "• Daily: ✅\n"
        "• Shop: ✅\n"
        "• Payments: ⏳\n"
        "• Votes: ✅\n"
        "• Mini-App: ✅\n"
        "• i18n: ✅\n"
        "• Referral: ⏳"
    )

@router.message(Command("full_check"))
async def full_check_cmd(message: types.Message):
    if not is_admin(message):
        await message.reply(get_string("access_denied", get_user_lang(message.from_user.id)))
        return
    import subprocess, os
    
    checks = []
    # Webhook
    import httpx
    async with httpx.AsyncClient() as client:
        try:
            resp = await client.get("https://telegrambot-production-a4c0.up.railway.app/")
            checks.append(("Webhook", resp.status_code == 200))
        except:
            checks.append(("Webhook", False))
    
    # DB
    from src.bot.db.database import engine
    try:
        async with engine.begin() as conn:
            await conn.execute(text("SELECT 1"))
        checks.append(("Database", True))
    except:
        checks.append(("Database", False))
    
    msg = "🔍 Full System Check\n\n"
    for name, ok in checks:
        msg += f"{'✅' if ok else '❌'} {name}\n"
    
    await message.reply(msg)
